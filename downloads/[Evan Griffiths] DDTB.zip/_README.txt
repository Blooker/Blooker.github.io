------------------------------------
PC Controls
------------------------------------
WASD: Move
Space: Jump

Hold left click: Aim attack
Release left click: Attack towards mouse

Right click: Dash towards mouse


------------------------------------
Xbox Controls
------------------------------------
Left stick/D-Pad: Move
A: Jump

Hold right stick in direction: Aim attack
Let go of right stick: Attack in that direction

Left Bumper: Dash in direction that Left stick/D-Pad is pointing



------------------------------------
Tips
------------------------------------
- You can dash once in the air, but get another dash by hitting the ball or landing on the floor

- Try wall jumping by moving into wall in the air and pressing jump at the same time