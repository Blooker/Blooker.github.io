INSTRUCTIONS
------------
W to move forward, A and D to turn left and right, Space bar to shoot

You have an overall score multiplier that increases if you shoot multiple asteroids without missing, as well as a distance multiplier that rewards long range shots.
Shoot all the pieces of a heart asteroid to gain a life back if you lose one!

NOTE
----
Windows SmartScreen might pop up on first launch and warn you that the EXE is a virus, but just disregard this as it's a false alarm.